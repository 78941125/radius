/* Prepended at openssl package build-time.  Don't include this file directly,
 * use <openssl/opensslconf.h> instead. */

#ifndef openssl_opensslconf_multilib_redirection_h
#error "Don't include this file directly, use <openssl/opensslconf.h> instead!"
#endif

